package Sheet1;

public class CounterTest {
    public static void main(String[] args) {
        Counter counter = new Counter();
        for (int i = 0; i < 10; i++) {
            counter.increment();
            System.out.println(STR."Incremented: \{counter.get()}");
            counter.decrement();
            System.out.println(STR."Decremented: \{counter.get()}");
        }
    }

}
