package Sheet2;
import java.util.Scanner;

public class BruchTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("For which N should it get tested?:");
        long n = input.nextLong();
        Bruch bruch = new Bruch(1, 1);
        for (int i = 1; i < n; i++) {
            Bruch b = new Bruch(1, i);
            bruch.add(b);
            System.out.println(STR."Iteration \{i}: \{bruch.get()}");
        }
        System.out.println("Give me N to approximate e:");
        n = input.nextLong();
        bruch = new Bruch(1, 1);
        System.out.println(STR."Approximatly: \{bruch.e(n).get()}");
    }
}
